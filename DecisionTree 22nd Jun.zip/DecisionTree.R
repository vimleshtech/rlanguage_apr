
#install.packages("party")

library("party")

readingSkills 
str(readingSkills )

write.csv(readingSkills,"C:\\Users\\vkumar15\\Desktop\\Desktop - Training\\Python-Batch-20thMay\\DataScience and ML\\out.csv")


##
#ctree(y~x1+x2+x2)
input.dat <- readingSkills # readingSkills[c(1:105),]

out <- ctree(nativeSpeaker~age+shoeSize+score,data=input.dat)

plot(out)







