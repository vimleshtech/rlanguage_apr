
### vector : is collection of similar type data  (vector is one dimenssion)
### 

data1 <- c(111,222,333,444,55)
d <- 1:10 
d <- c(1:10 )
seq(1,10)
seq(1,10,by=.1)

data2 <- c(111,222,333,444,55)


#cbind 
cbind(data1,data2)

#rbind 
rbind(data1,data2)

#Vector operations
data2 * 2

v2 = data2 * 2

mean(data2*.18)

data1+data2


##add new element in existing vector
v <- c() #empty vector

v = append(v,100)

fact <- function(x){
  
    if (x == 1){
      
      return(x)
    }else{
      
      return(x*fact(x-1))
    }
  
}

i = 1
while(i<10){
  
  v = append(v,fact(i))
  
  i=i+1
}


##methods
max(v)
min(v)
mean(v)
var(v)
sd(v)

quantile(v)

#pecentile 
quantile(v,c(.33,.56,.78,.87,.99))


v
########## Factor : is categorial data or Levels data 
###################################################
gender <- c("male","female","female","male","female")

is.factor(gender) #is.type() return true or false 

g = as.factor(gender) #as.type() convert to new type 


##############  matrix ############
###################################
a <- c (1:9)

matrix(a,nrow = 3, ncol =  3)
matrix(a,nrow = 3, ncol =  3,byrow =  TRUE)

matrix(a,nrow = 2, ncol =  2)


#### dataframe : table
#############################################
id <- c(1:5)
name <- c("jatin","divya","kshitz","nitisha","monika")
gender <- c("male","female","male","female","female")
sal <- c(334444,543333,22222,33444,4444)


emp  = data.frame(id,name,gender,sal)

#read vector 
emp$name
emp$id
emp$sal

#get count
length(emp)  ##retun vector/col count

length(emp$name) #return row count


#read by index 
emp #read all data from data frame
emp$id   #read one vector


emp$id[1] #read one value from given vector and index

#return all columns of given row
emp[1,]   #emp[row index, col index]

#return all rows of 1st column
emp[,1]   

#return 2nd row and 2nd vector value
emp[2,2]  

#return 2 to 4 rows and all vector 
emp[2:4,]  


#return 2 to 4 rows and 2 to 3 vector / column 
emp[2:4,2:3]  



##cbind(id,name,gender,sal)

## list  : can mix type
l <- list(11,"skjsfgs",TRUE,emp,c(1:100))

l[1]
l[4]
l[5]


## array 

vector1 <- c(5,9,3)
vector2 <- c(10,11,12,13,14,15)

#mege two vector
c(vector1,vector2)

# Take these vectors as input to the array.
result <- array(c(vector1,vector2),dim = c(3,3,2))

print(result)



