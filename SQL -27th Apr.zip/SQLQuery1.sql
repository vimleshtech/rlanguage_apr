

use hrms

select * from j_employee
select * from j_salary


--inner join 
select e.eid,e.name,e.gender,s.sal
from j_employee  e inner join j_salary as s
		on e.eid = s.id 


--left join 		 
select e.eid,e.name,e.gender,s.sal
from j_employee  e left join j_salary as s
		on e.eid = s.id 



--right 
select e.eid,e.name,e.gender,s.sal
from j_employee  e right join j_salary as s
		on e.eid = s.id 


--full outer
select e.eid,e.name,e.gender,s.sal
from j_employee  e full outer join j_salary as s
		on e.eid = s.id 


select * from  j_employee
--out : eid name mgrname 

select e.eid,e.name,m.name as mgrname
from j_employee e left join j_employee as m
	on e.mgr_id = m.eid 


--cross join 
select *
from j_employee,j_salary 
where j_employee.eid = j_salary.id 


/*
emp:
eid name 
1   raman
2   jatin


mon_sal
eid   month   amt
1     jan     444
2    jan     55
1   feb     555


output:
eid name total_sal
1   raman  999
2   jatin   55


*/
