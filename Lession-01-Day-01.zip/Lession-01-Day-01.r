
a =11
b =33

c =a+b
print(c)

x <-c(1:5)
y <- x*2
plot(x,y)


#reserved words 

letters
LETTERS
month.name

#variables

a <- 11
b <- 44
#addition of two numebrs 
c <- a+b
print(c)



#check / return data type 
a = 11
typeof(a)

a ="sjsgsf 233"
typeof(a)


#return true or false 
a =11
is.numeric(a)
is.character(a)

a ="sjkgss"
is.character(a)

#type casting 
a ="1"
b ="33"

a = as.numeric(a)
b = as.numeric(b)

c =a+b
print(c)

################### vector 

Sales <- c(1:100)  #one column is vector , one data type

sales  <- c(11,222,33,444,55,534333)

max(sales)
min(sales)

mean(sales)

var(sales)

sd(sales)






##
a =1111
b =44

if(a>b){
  print("a is gt ")
  
}else{
  
  print("b is gt")
}


###
a =1111
b =443333
c =4444444
if(a>b && a>c){
  print("a is gt ")
  
}else if(b>a && b>c){
  
  print("b is gt")
}else{
  
  print("c is gt")
}


##
i =1
while(i<10){
  
  print(i)
  i=i+1
}

#print in rev
i =10
while(i>0){
  
  print(i)
  i=i-1
}

##for 
v <- c(1:10)
s = 0
for(a in v){
  
  print(a)
  
  if(a %% 3 ==0){
    #break
    next
  }
  s =s+a
}
print(s)




###
i =1 
repeat{
  
  print(i)
  i=i+1
  if(i >10){
    break
  }
}
