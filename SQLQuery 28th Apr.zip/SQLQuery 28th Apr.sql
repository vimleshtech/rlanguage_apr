/*
union     : to merge two or more than two tables vertically 
		-table structure should be same 
		-There are two types of union 
				-union   : return distinct rows
				-union all : return all rows
		   Example:
			A :
				id name
				1  nitin
				2  jatin
			B:
				id name gender
				1   nitin  m
				10  rahul  m

		select id , name from A
		union 
		select id,name from B 			
subquery  : 
			
functions : 
*/

create database hrms
use school


select * from [dbo].[emp]

insert into emp(id)
values(10)

select COUNT(*) from [dbo].[emp]
select COUNT(name) from [dbo].[emp]

select id+[name] from emp
select CONVERT(varchar, id) + isnull(name,'') from emp
---A  : 10
---B  : 2
select * from A, B   --20
select * from emp,emp_details
select * from emp_details


---A  : 5
---B  : no rows 
select * from A, B   -- 5

--union 
select * from emp 
select * from emp_details 

select id,name from emp 
union 
select id,address from emp_details
 

select id,name from emp 
union  all
select id,address from emp_details

select id from emp 
union  
select id from emp_details


select id from emp 
union   all
select id from emp_details
    
	select * from emp 
	alter table emp 
	add gener varchar(100)

insert into emp 
select 11,'raman','male'
union select 12,'jatin','male'
union select 13,'monika','female'
union select 14,'monika','female'
union select 15,'monika','female'
union select 16,'monika','female'
union select 17,'monika','female'
union select 18,'monika','female'
union select 19,'monika','female'
union select 20,'monika','female'
union select 21,'monika','female'
union select 22,'monika','female'
union select 23,'monika','female'
union select 24,'monika','female'
union select 25,'monika','female'
union select 26,'monika','female'
union select 27,'monika','female'
union select 28,'monika','female'
union select 29,'monika','female'
union select 30,'monika','female'

select * from emp 

create table product
(
pid int,
pname varchar(100),
pprice int,
sprice int
)

create table trans
(
tid int identity(1,1) , -- 1 start from 1 , 
pid int,
tran_type varchar(10),
qty int,
createdate datetime default getdate()
)


insert into product
values(1,'dove',35,44),
(2,'iphone',45000,60000),
(3,'hp laptop',35000,44000),
(4,'sony tv',23000,30000)


select * from product 

select 

	p.pid,
	p.pname,
	(select sum(qty) from trans where tran_type='P' and pid = p.pid) as tp ,
	(select sum(qty) from trans where tran_type='S' and pid = p.pid) as ts ,
	(select sum(qty) from trans where tran_type='P' and pid = p.pid)
	-(select sum(qty) from trans where tran_type='S' and pid = p.pid) as remaining
from product as p


--pid pname total_purchase_qty  total_sale_qty  remaining_qty total_cost  total_margin
select * from trans 
select pid, sum(qty) from trans where tran_type='S'
group by pid 

select pid,SUM(qty) as total_purchase_qty,
(select SUM(qty) as total_Sales_qty from trans
where tran_type='S')
 from trans
where tran_type='P' group by pid

select pid,SUM(qty) as total_purchase_qty
from trans
where tran_type='P' group by pid 

select pid, SUM(qty) as total_Sales_qty from trans
where tran_type='S' group by pid


--output:
================
 insert into trans(pid,tran_type, qty)
 values(1,'P',100),
 (1,'S',10),
 (1,'S',50),
 (1,'P',400),
 (2,'P',400),
 (1,'S',10),
 (2,'S',10),
 (3,'P',500)

 (1,'P',100)


 /*
 functions : 
 */
 --date
 select GETDATE()

 select DATEPART(yyyy,getdate())
 select DATEPART(mm,getdate())
select DATEPART(DAY,getdate())
select DATEPART(DAYOFYEAR,getdate())

select DATEDIFF(yyyy,'1990-11-01',getdate())
select DATEDIFF(day,'1990-11-01',getdate())

select GETDATE()+10

select DATEADD(year,10,getdate())

select DATEPART(weekday,getdate())

select DATEPART(weekday,DATEADD(year,10,getdate()))


select DATEPART(weekday,'1989-11-29')

-
MAX()
min()
sum()
avg()
count()


--
upper()
lower()
len()
ltrim()
rtrim()

select *, UPPER(pname) from product
select *, lower(pname) from product
select *, len(pname) from product
select *, ltrim(pname) from product
select *, rtrim(pname) from product



