
exp  = c(3,4,5,6,2,6)
sal  = c(10000,12000,15000,20000,9000,21000)


#linear model 
#lm(y~x)
reg <- lm(sal~exp)

newcandidates <-data.frame(exp<-c(11,1,20,8,7))
predict(reg,newcandidates)




###
mtcars
str(mtcars)
# mpg  : y 
# cyl : x1
# hp : x2 
# wt : x3

mpg = mtcars$mpg
cyl = mtcars$cyl
hp = mtcars$hp
wt = mtcars$wt

r<- lm(mpg~cyl+hp+wt)

newcars <-data.frame(cyl<-c(3,9),hp<-c(150,378),wt<-c(3.0,4.2))

predict(r,newcars)


####logistics 
IS_WORKING  = TESTDATA_csv$IS_WORKING
EXP = TESTDATA_csv$EXP
LIB = TESTDATA_csv$LIB
ITR= TESTDATA_csv$ITR
OTHER= TESTDATA_csv$OTHER



#, family=binomial(link="logit")

logitMod <- glm(OTHER ~ IS_WORKING + EXP + LIB + ITR, data=TESTDATA_csv)

newdata = data.frame(IS_WORKING<-c(0),EXP<-c(1), LIB<-c(0),ITR<-c(0))

str(newdata$)

#predicted <- plogis(predict(logitMod, newdata))  # predicted scores

# or
 predict(logitMod, newdata, type="response")  # predicted scores





