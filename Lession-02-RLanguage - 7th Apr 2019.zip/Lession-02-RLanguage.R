#global variable 

a =11

#no argument no return 
test_fun <- function(){

  
  #scope will be in function 
   d = 444  
   
  print("test function ")
  print("this is first modular programing")
  
} 

#no argument with return 
get_data <- function(){
  
  sale_data = c(1:100)
  m = max(sale_data)
  
  return(m)
  
}

#argument with no return
get_sum <- function(sales){
  
  
  total = 0
  for(s in sales){
    
      total = total + s
  }
  
  print(total)
  
}

#argument with return 
get_sub = function(a,b){
  
  c =a+b
  return(c)
}


#call to function 
test_fun()

o = get_data()
print(o)

print(get_data())


d = (111,222,333,444,3,3,3,444)
get_sum(d)

o = get_sub(11,22)
print(o)


#recussive function 
fact <- function(n){
  
  if (n ==1){
    return(n) 
  }else{
    
    return (n*fact(n-1)) #5 * 4 * 3 * 2 
  }
  
  
}

o = fact(5)